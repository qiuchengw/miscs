# Thor plugin

This plugin adds completion for [Thor](http://whatisthor.com/), 
a ruby toolkit for building powerful command-line interfaces.

To use it, add `thor` to the plugins array in your zshrc file:

```zsh
plugins=(... thor)
```
